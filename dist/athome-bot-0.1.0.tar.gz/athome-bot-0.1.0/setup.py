# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src', 'src.db', 'src.func']

package_data = \
{'': ['*'],
 'src': ['build/*',
         'build/static/css/*',
         'build/static/js/*',
         'build/static/media/*']}

install_requires = \
['aiogram>=2.25.1,<3.0.0',
 'dramatiq>=1.14.0,<2.0.0',
 'pygismeteo>=5.0.6,<6.0.0',
 'pymongo>=4.3.3,<5.0.0',
 'python-dotenv>=0.21.1,<0.22.0',
 'redis>=4.5.1,<5.0.0',
 'typer>=0.7.0,<0.8.0']

entry_points = \
{'console_scripts': ['get_weather = src.func.info:get_weather',
                     'setup_db = src.db.postgresql:setup_db',
                     'start = src.main:run',
                     'test_dramatiq = src.tasks:run']}

setup_kwargs = {
    'name': 'athome-bot',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'StanisLove',
    'author_email': 'sta-tun-slav@yandex.ru',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
